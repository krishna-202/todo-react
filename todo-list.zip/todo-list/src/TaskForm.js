import React, { useState } from "react";

const TaskForm = ({ addTask }) => {
  const [description, setDescription] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!description) {
      return;
    }

    const newTask = {
      id: Date.now(),
      description,
      completed: false,
    };

    addTask(newTask);
    setDescription("");
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <button type="submit">add task</button>
      </form>
    </div>
  );
};

export default TaskForm;
