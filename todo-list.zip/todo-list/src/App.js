import logo from "./logo.svg";
import "./App.css";
import { useEffect, useState } from "react";
import TaskForm from "./TaskForm";
import Task from "./Task";

function App() {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    const storedTasks = JSON.parse(localStorage.getItem("tasks"));
    if (storedTasks) {
      setTasks(storedTasks);
    }
  });

  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  const addTask = (task) => {
    setTasks([...tasks, task]);
  };

  const removeTask = (taskId) => {
    const updatedTasks = tasks.filter((task) => task.id !== taskId);
    setTasks(updatedTasks);
  };

  return (
    <div>
      <h1>Todo List</h1>
      <TaskForm addTask={addTask}></TaskForm>
      {tasks.map((task) => {
        <Task
          key={task.id}
          task={task}
          editTask={editTask}
          removeTask={removeTask}
        />;
      })}
    </div>
  );
}

export default App;
