import { getValue } from "@testing-library/user-event/dist/utils";
import React, { useState } from "react";

const Task = ({ task, editTask, removeTask }) => {
  const [isEditing, setIsEditing] = useState(false);

  const [newDescription, setNewDescription] = useState(task.description);

  const handleEdit = () => {
    if (isEditing) {
      editTask(task.id, newDescription);
    }
    setIsEditing(!isEditing);
  };

  return (
    <div>
      {isEditing ? (
        <input
          type="text"
          value={newDescription}
          onchange={(e) => setNewDescription(e.target.value)}
        />
      ) : (
        <span>{task.description}</span>
      )}

      <button onClick={handleEdit}>{isEditing ? "Save" : "Edit"}</button>

      <button onClick={() => removeTask(task.id)}>Delete</button>
    </div>
  );
};

export default Task;
